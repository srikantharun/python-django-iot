"""
WAF Requirements Test Suite

Pytest-based tests that:
1. Discover waf_requirements.yaml from each custom module
2. Run positive/negative/injection tests for each requirement
3. Verify via CloudWatch logs
4. Generate coverage reports
"""
from __future__ import annotations

import pytest
from typing import Optional

from .models import WAFTestConfig, WAFRequirement, TestStatus, CheckType
from .test_runner import WAFTestRunner
from .http_client import WAFHttpClient, WAFRequest
from .cloudwatch_client import CloudWatchWAFClient


class TestWAFRequirements:
    """
    Parametrized tests for all WAF requirements.

    Tests are automatically generated for each requirement found in
    waf_requirements.yaml files under modules/custom/.
    """

    @pytest.mark.positive
    def test_valid_request_allowed(
        self,
        test_runner: WAFTestRunner,
        config: WAFTestConfig,
        requirement: WAFRequirement,
    ):
        """
        Test 1: Valid request matching requirement should be ALLOWED.

        Verification:
        - Request matches all conditions (uri, method, host, headers)
        - False positive label IS present in CloudWatch
        - WAF action is ALLOW
        """
        result = test_runner._run_positive_test(config, requirement)

        assert result.status == TestStatus.PASS, (
            f"\n{'='*60}\n"
            f"POSITIVE TEST FAILED\n"
            f"{'='*60}\n"
            f"Policy:      {config.policy.name}\n"
            f"Requirement: {requirement.id}\n"
            f"URI:         {requirement.uri}\n"
            f"Method:      {requirement.method}\n"
            f"Host:        {requirement.host}\n"
            f"Request ID:  {result.request_id}\n"
            f"HTTP Status: {result.http_status}\n"
            f"WAF Action:  {result.actual_action}\n"
            f"Expected:    ALLOW\n"
            f"Message:     {result.message}\n"
            f"Labels:      {result.actual_labels}\n"
            f"{'='*60}"
        )

    @pytest.mark.negative
    @pytest.mark.parametrize("tamper_field", ["uri", "method", "host"])
    def test_tampered_request_blocked(
        self,
        test_runner: WAFTestRunner,
        config: WAFTestConfig,
        requirement: WAFRequirement,
        tamper_field: str,
    ):
        """
        Test 2: Request with tampered field should be BLOCKED.

        Verification:
        - One condition is wrong (uri, method, or host)
        - Detection label IS present
        - False positive label is NOT present
        - WAF action is BLOCK
        """
        result = test_runner._run_negative_test(config, requirement, tamper_field)

        assert result.status == TestStatus.PASS, (
            f"\n{'='*60}\n"
            f"NEGATIVE TEST FAILED - SECURITY GAP\n"
            f"{'='*60}\n"
            f"Policy:      {config.policy.name}\n"
            f"Requirement: {requirement.id}\n"
            f"Tampered:    {tamper_field}\n"
            f"Request ID:  {result.request_id}\n"
            f"HTTP Status: {result.http_status}\n"
            f"WAF Action:  {result.actual_action}\n"
            f"Expected:    BLOCK\n"
            f"Message:     {result.message}\n"
            f"{'='*60}"
        )

    @pytest.mark.injection
    @pytest.mark.xss
    @pytest.mark.parametrize("payload", [
        "<script>alert(1)</script>",
        "<img src=x onerror=alert(1)>",
        "<svg/onload=alert(1)>",
    ])
    def test_xss_injection_blocked(
        self,
        test_runner: WAFTestRunner,
        config: WAFTestConfig,
        requirement: WAFRequirement,
        payload: str,
    ):
        """
        Test 3a: XSS payload should be BLOCKED even on allowlisted endpoint.

        Attacks must ALWAYS be blocked regardless of false positive exceptions.
        """
        # Skip if XSS not supported
        if CheckType.XSS.value not in config.labels.supported_checks:
            pytest.skip(f"XSS not supported by {config.policy.name}")

        result = test_runner._run_injection_test(
            config, requirement, CheckType.XSS, payload
        )

        assert result.status == TestStatus.PASS, (
            f"\n{'='*60}\n"
            f"CRITICAL: XSS NOT BLOCKED\n"
            f"{'='*60}\n"
            f"Policy:      {config.policy.name}\n"
            f"Requirement: {requirement.id}\n"
            f"Payload:     {payload}\n"
            f"Request ID:  {result.request_id}\n"
            f"HTTP Status: {result.http_status}\n"
            f"WAF Action:  {result.actual_action}\n"
            f"Expected:    BLOCK\n"
            f"{'='*60}"
        )

    @pytest.mark.injection
    @pytest.mark.sqli
    @pytest.mark.parametrize("payload", [
        "' OR '1'='1",
        "1; DROP TABLE users--",
        "1+union+select+1,2,3",
    ])
    def test_sqli_injection_blocked(
        self,
        test_runner: WAFTestRunner,
        config: WAFTestConfig,
        requirement: WAFRequirement,
        payload: str,
    ):
        """
        Test 3b: SQLi payload should be BLOCKED even on allowlisted endpoint.

        Attacks must ALWAYS be blocked regardless of false positive exceptions.
        """
        # Skip if SQLi not supported
        if CheckType.SQLI.value not in config.labels.supported_checks:
            pytest.skip(f"SQLi not supported by {config.policy.name}")

        result = test_runner._run_injection_test(
            config, requirement, CheckType.SQLI, payload
        )

        assert result.status == TestStatus.PASS, (
            f"\n{'='*60}\n"
            f"CRITICAL: SQLi NOT BLOCKED\n"
            f"{'='*60}\n"
            f"Policy:      {config.policy.name}\n"
            f"Requirement: {requirement.id}\n"
            f"Payload:     {payload}\n"
            f"Request ID:  {result.request_id}\n"
            f"HTTP Status: {result.http_status}\n"
            f"WAF Action:  {result.actual_action}\n"
            f"Expected:    BLOCK\n"
            f"{'='*60}"
        )


class TestCoverageThreshold:
    """Test that coverage meets minimum threshold."""

    def test_coverage_meets_threshold(
        self,
        test_runner: WAFTestRunner,
        session_config: dict,
    ):
        """Verify test coverage meets the required threshold."""
        module_filter = session_config.get("module_filter")
        threshold = session_config.get("coverage_threshold", 80.0)

        report = test_runner.run_all_tests(policy_filter=module_filter)

        assert report.coverage_percent >= threshold, (
            f"\n{'='*60}\n"
            f"COVERAGE BELOW THRESHOLD\n"
            f"{'='*60}\n"
            f"Coverage:   {report.coverage_percent:.1f}%\n"
            f"Threshold:  {threshold}%\n"
            f"Tested:     {report.tested_requirements}/{report.total_requirements}\n"
            f"{'='*60}"
        )

        assert report.pass_rate >= threshold, (
            f"\n{'='*60}\n"
            f"PASS RATE BELOW THRESHOLD\n"
            f"{'='*60}\n"
            f"Pass Rate:  {report.pass_rate:.1f}%\n"
            f"Threshold:  {threshold}%\n"
            f"Passed:     {report.passed_requirements}/{report.tested_requirements}\n"
            f"{'='*60}"
        )
