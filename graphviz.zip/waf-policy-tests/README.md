# WAF Policy Testing Framework

Integration testing for `terraform-aws-fms-policies` WAF rules.

## Quick Start

```bash
# Install dependencies
make test-install

# Validate requirements file
make test-validate MODULE=ease_global_v7

# Run tests for a module
make test MODULE=ease_global_v7 \
    WAF_ENDPOINT=https://your-cloudfront.example.com \
    WAF_LOG_GROUP=aws-waf-logs-ease-v7
```

## Directory Structure

```
terraform-aws-fms-policies/
├── Makefile                    # make init/plan/apply + make test MODULE=xxx
├── pyproject.toml              # Test dependencies
├── modules/custom/
│   ├── hase_global/hase_ob_v4/
│   │   ├── main.tf
│   │   └── waf_requirements.yaml   # Test requirements
│   ├── payme_global/payme_global_v8/
│   │   └── waf_requirements.yaml
│   └── ease_global/ease_global_v7/
│       └── waf_requirements.yaml
└── tests/
    ├── conftest.py
    └── waf/
        ├── models.py
        ├── http_client.py
        ├── cloudwatch_client.py
        ├── test_runner.py
        └── test_waf_requirements.py
```

## waf_requirements.yaml Format

Each module contains a `waf_requirements.yaml` defining:

```yaml
policy:
  name: ease_global_v7
  cloudwatch_log_group: "aws-waf-logs-ease-v7"

labels:
  detection:
    size: "awswaf:managed:aws:core-rule-set:SizeRestrictions_Body"
  false_positive_namespace:
    size: "easev7:restrictsize-fp:"
  supported_checks:
    - size
    - xss
    - sqli

requirements:
  - id: EASE-V7-001
    uri: /approval
    method: POST
    host: api.ease.hsbc.com
    fp_labels:
      size: "easev7:restrictsize-fp:100211"
    test_config:
      test_large_body: true
      large_body_size_bytes: 111267
      expected_action: ALLOW
```

## Test Types

| Test | Description | Expected |
|------|-------------|----------|
| Positive | Valid request matches allowlist | ALLOW |
| Negative | Tampered request (uri/method/host) | BLOCK |
| Injection | XSS/SQLi payload on valid request | BLOCK |

## Environment Variables

| Variable | Description |
|----------|-------------|
| `WAF_ENDPOINT` | WAF-protected CloudFront URL |
| `WAF_LOG_GROUP` | CloudWatch log group |
| `AWS_REGION` | AWS region (default: eu-west-1) |
| `AWS_ACCOUNT_ID` | For label interpolation |

## CI/CD Usage

```yaml
# After terraform apply for a module
- name: Test WAF Policy
  run: |
    make test MODULE=ease_global_v7 \
      WAF_ENDPOINT=${{ steps.tf.outputs.waf_endpoint }} \
      WAF_LOG_GROUP=${{ steps.tf.outputs.log_group }}
```
